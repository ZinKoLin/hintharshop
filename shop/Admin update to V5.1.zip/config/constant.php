<?php


//status
const ACTIVE = 'active';
const INACTIVE = 'inactive';

//management section

const MANAGEMENT_SECTION = [
    'dashboard_management' => 'dashboard_management',
    'pos_management' => 'pos_management',
    'order_management' => 'order_management',
    'product_management' => 'product_management',
    'business_management' => 'business_management',
    'employee_management' => 'employee_management',
    'deliveryman_management' => 'deliveryman_management',
    'customer_management' => 'customer_management',
    'report_management' => 'report_management',
];